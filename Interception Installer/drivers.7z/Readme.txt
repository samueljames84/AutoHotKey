Alternative to installing "install-interception.exe"
You can manually copy the 2 files to the following location.
"C:\Windows\System32\drivers\keyboard.sys"
"C:\Windows\System32\drivers\mouse.sys"
After copying needs a reboot.